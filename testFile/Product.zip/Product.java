public class Product{
	public String productName;
	public String expDate;
	public int quantity;

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductName() {
		return productName;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void getQuantity() {
		return quantity;
	}

}